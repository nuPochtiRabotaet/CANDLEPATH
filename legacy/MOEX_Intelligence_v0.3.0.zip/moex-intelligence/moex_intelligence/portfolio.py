"""RUB-only virtual cash ledger. No brokerage connectivity or order execution."""
from __future__ import annotations
from collections import defaultdict
from datetime import date
import json
from pathlib import Path
import sqlite3
import uuid
import numpy as np
import pandas as pd
from moex import identifier
from .validation import finite, integer

KINDS = {'deposit', 'withdrawal', 'buy', 'sell', 'dividend', 'coupon'}


def validate_event(event):
    e = dict(event)
    e['date'] = date.fromisoformat(e['date']).isoformat()
    if e.get('kind') not in KINDS: raise ValueError('Unknown ledger event kind.')
    if e.get('currency', 'RUB') != 'RUB': raise ValueError('MVP portfolio supports RUB only; no implicit FX conversion.')
    e['currency'] = 'RUB'
    e['fee'] = finite(e.get('fee', 0.), 'fee', 0, 1e12)
    if e['kind'] in {'buy','sell'}:
        e['symbol'] = identifier(e['symbol'])
        e['quantity'] = integer(e['quantity'], 'quantity', 1, 100000000)
        e['price'] = finite(e['price'], 'price (RUB per unit)', 1e-8, 1e12)
    else:
        e['amount'] = finite(e['amount'], 'amount', 1e-8, 1e12)
        if e['kind'] in {'dividend','coupon'}:
            e['symbol'] = identifier(e['symbol'])
            if not isinstance(e.get('source'), str) or not e['source'].strip():
                raise ValueError('Dividend/coupon requires a source reference, e.g. broker statement date.')
    if len(json.dumps(e)) > 4096: raise ValueError('Event too large.')
    return e


def ledger_state(events):
    if len(events) > 5000: raise ValueError('Portfolio limited to 5000 events.')
    ordered = sorted([validate_event(e) for e in events], key=lambda e: e['date'])
    cash, contributed, realized, income = 0., 0., 0., 0.
    positions = defaultdict(lambda: {'quantity': 0, 'cost_basis': 0.})
    for e in ordered:
        kind = e['kind']; fee = e['fee']
        if kind == 'deposit': cash += e['amount']-fee; contributed += e['amount']
        elif kind == 'withdrawal': cash -= e['amount']+fee; contributed -= e['amount']
        elif kind in {'dividend','coupon'}: cash += e['amount']-fee; income += e['amount']-fee
        else:
            pos = positions[e['symbol']]; qty = e['quantity']; gross = qty*e['price']
            if kind == 'buy':
                cash -= gross+fee; pos['quantity'] += qty; pos['cost_basis'] += gross+fee
            else:
                if qty > pos['quantity']: raise ValueError(f"{e['symbol']}: cannot sell more units than held")
                removed = pos['cost_basis'] * qty / pos['quantity']
                pos['quantity'] -= qty; pos['cost_basis'] -= removed
                cash += gross-fee; realized += gross-fee-removed
        if cash < -1e-7: raise ValueError(f"Insufficient cash on {e['date']}; deposits must precede purchases.")
    return {'cash': max(cash, 0.), 'net_contributions': contributed, 'realized_pnl': realized, 'income': income,
            'positions': {k:v for k,v in positions.items() if v['quantity']}, 'events': ordered}


def analyze_portfolio(events, marks):
    """Marks: {ticker: {price: RUB per unit incl. bond accrued interest, as_of, source}}."""
    state = ledger_state(events)
    positions = []
    last_event = max((e['date'] for e in state['events']), default=None)
    for symbol, p in state['positions'].items():
        mark = marks.get(symbol)
        if not isinstance(mark, dict): raise ValueError(f'Missing dated valuation for {symbol}.')
        price = finite(mark.get('price'), f'{symbol} valuation', 1e-8, 1e12)
        as_of = date.fromisoformat(mark['as_of']).isoformat()
        if last_event and as_of < last_event: raise ValueError('Valuation must not predate ledger events.')
        if not isinstance(mark.get('source'), str) or not mark['source'].strip(): raise ValueError('Valuation source required.')
        value = price * p['quantity']
        positions.append({'symbol': symbol, **p, 'price': price, 'market_value': value,
                          'unrealized_pnl': value-p['cost_basis'], 'as_of': as_of, 'source': mark['source']})
    dates = {p['as_of'] for p in positions}
    if len(dates) > 1: raise ValueError('All portfolio valuations must use the same as_of date.')
    nav = state['cash'] + sum(p['market_value'] for p in positions)
    for p in positions: p['weight_pct'] = p['market_value']/nav*100 if nav else 0.
    return {k:state[k] for k in ['cash','net_contributions','realized_pnl','income']} | {
        'equity': nav, 'total_pnl': nav-state['net_contributions'], 'positions': positions,
        'as_of': next(iter(dates), last_event), 'currency': 'RUB',
        'limitations': ['Manual ledger and sourced valuations; dividend/coupon source is not automatically verified.',
                        'Bond entries and marks must be dirty RUB price per bond, not quoted percent of face value.',
                        'Snapshot P&L is not time-weighted return. Use dated valuation history for return/drawdown.']}


def portfolio_curve(events, prices):
    """Strict complete valuations at each date; external flows assumed at start of day."""
    state = ledger_state(events)
    if prices.empty or not isinstance(prices.index, pd.DatetimeIndex) or prices.index.hasnans or prices.index.has_duplicates or not prices.index.is_monotonic_increasing:
        raise ValueError('Unique increasing daily valuation index required.')
    dates = set(prices.index.strftime('%Y-%m-%d'))
    if any(e['date'] not in dates for e in state['events']):
        raise ValueError('Each event date must have a valuation row; no implicit holiday shifting.')
    previous, unit_nav, curve = 0., 1., []
    history = []
    for day, marks in prices.iterrows():
        daystr = str(day.date()); todays = [e for e in state['events'] if e['date'] == daystr]
        history.extend(todays)
        snapshot = analyze_portfolio(history, {sym:{'price':val,'as_of':daystr,'source':'supplied valuation history'} for sym,val in marks.items()})
        external = sum(e['amount']*(1 if e['kind']=='deposit' else -1) for e in todays if e['kind'] in {'deposit','withdrawal'})
        denominator = previous + external
        if denominator < 0 or denominator == 0 and snapshot['equity'] != 0:
            raise ValueError('Daily-flow convention cannot measure this return; add intraday valuations.')
        daily_return = snapshot['equity']/denominator-1 if denominator else 0.
        unit_nav *= 1+daily_return
        curve.append({'date':day, 'equity':snapshot['equity'], 'external_flow':external,'daily_return':daily_return, 'unit_nav':unit_nav})
        previous = snapshot['equity']
    frame = pd.DataFrame(curve).set_index('date')
    values = np.r_[1., frame['unit_nav']]
    frame['drawdown'] = (values / np.maximum.accumulate(values)-1)[1:]
    return frame, {'time_weighted_return_pct': (unit_nav-1)*100, 'max_drawdown_pct': float(frame['drawdown'].min()*100),
                   'flow_timing': 'External deposits/withdrawals at beginning of each valuation day; no mark forward-fill.'}


def stress_test(snapshot, shocks):
    """One-step price shocks in percent. Cash unchanged. No guessed correlations."""
    if set(shocks) - {p['symbol'] for p in snapshot['positions']}:
        raise ValueError('Shock symbol not in portfolio.')
    loss = sum(p['market_value'] * finite(shocks.get(p['symbol'], 0), 'shock', -100, 500) / 100 for p in snapshot['positions'])
    return {'equity_before': snapshot['equity'], 'equity_after': snapshot['equity']+loss, 'change_rub': loss,
            'change_pct': loss/snapshot['equity']*100 if snapshot['equity'] else 0., 'shocks_pct': shocks,
            'assumption': 'Instantaneous specified price changes, unchanged cash; no forecast probabilities.'}


class PortfolioStore:
    """SQLite transactions prevent partial writes and lost updates across dashboard sessions."""
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db: db.execute('CREATE TABLE IF NOT EXISTS events (seq INTEGER PRIMARY KEY, id TEXT UNIQUE, body TEXT NOT NULL)')

    def connect(self):
        return sqlite3.connect(self.path, timeout=10)

    def load(self):
        with self.connect() as db: return [json.loads(r[0]) for r in db.execute('SELECT body FROM events ORDER BY seq')]

    def append_many(self, events):
        if not isinstance(events, list) or not events: raise ValueError('Nonempty event list required.')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            existing = [json.loads(r[0]) for r in db.execute('SELECT body FROM events ORDER BY seq')]
            clean = [validate_event(e) for e in events]
            ledger_state(existing+clean)
            for e in clean: db.execute('INSERT INTO events(id,body) VALUES (?,?)', (str(uuid.uuid4()), json.dumps(e,ensure_ascii=False)))
