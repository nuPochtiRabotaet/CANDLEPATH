from pathlib import Path
from streamlit.testing.v1 import AppTest

ROOT=Path(__file__).resolve().parents[1]


def app(): return AppTest.from_file(str(ROOT/'app.py'),default_timeout=30)


def test_six_pages_and_calculations(monkeypatch,tmp_path):
    monkeypatch.setenv('MOEX_DATA_DIR',str(tmp_path))
    at=app().run()
    assert not at.exception
    at.sidebar.radio(key='mode').set_value('Демо · искусственные данные').run()
    at.sidebar.button(key='load_history').click().run()
    assert not at.exception and len(at.metric)==4
    at.sidebar.radio(key='page').set_value('Market Explorer').run()
    assert not at.exception and len(at.dataframe)>0
    at.sidebar.radio(key='page').set_value('Time Machine').run()
    at.selectbox(key='runs').set_value(1000)
    at.button(key='FormSubmitter:simulation_form-Рассчитать сценарии').click().run()
    assert not at.exception and not at.error and len(at.metric)>=7
    at.sidebar.radio(key='page').set_value('Strategy Lab').run()
    at.button(key='FormSubmitter:backtest_form-Проверить стратегию').click().run()
    assert not at.exception and not at.error and len(at.dataframe)>0
    at.sidebar.radio(key='page').set_value('AI Research').run()
    at.button(key='report').click().run()
    assert not at.exception and any('Исследование DEMO' in x.value for x in at.markdown)
    at.sidebar.radio(key='page').set_value('Portfolio').run()
    at.button(key='FormSubmitter:ledger_form-Сохранить запись').click().run()
    assert not at.exception and not at.error
    assert at.metric[0].value=='19,000.00 ₽'


def test_no_synthetic_fallback_on_live_error(monkeypatch):
    from moex_intelligence.data import get_engine
    def unavailable(*args): raise ValueError('network unavailable')
    monkeypatch.setattr(get_engine(),'frame_sync',unavailable)
    at=app().run()
    at.sidebar.button(key='load_history').click().run()
    assert not at.exception and len(at.error)==1 and 'network unavailable' in at.error[0].value
    assert 'dataset' not in at.session_state
