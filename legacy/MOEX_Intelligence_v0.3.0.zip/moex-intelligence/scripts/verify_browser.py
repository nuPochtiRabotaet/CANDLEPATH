"""Optional real Chromium UI smoke. Requires playwright==1.51.0 and chromium headless shell."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
from urllib.request import urlopen
from playwright.sync_api import sync_playwright


def main():
    root=Path(__file__).resolve().parents[1]
    evidence=root/'docs/ui';evidence.mkdir(exist_ok=True)
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    errors=[]
    with tempfile.TemporaryDirectory() as data_dir, open(evidence/'server.log','w') as log:
        env={**os.environ,'MOEX_DATA_DIR':data_dir}
        command=[os.getenv('MOEX_APP_PYTHON',sys.executable),'-m','streamlit','run','app.py','--server.port',str(port),'--server.address','127.0.0.1']
        proc=subprocess.Popen(command,cwd=root,env=env,stdout=log,stderr=log)
        try:
            for _ in range(100):
                try:
                    with urlopen(f'http://127.0.0.1:{port}/_stcore/health',timeout=.2) as r:
                        assert r.read()==b'ok';break
                except OSError:
                    if proc.poll() is not None:raise RuntimeError('Streamlit exited')
                    time.sleep(.1)
            else:raise TimeoutError('Streamlit start timeout')
            with sync_playwright() as p:
                browser=p.chromium.launch(headless=True,args=['--no-sandbox'])
                page=browser.new_page(viewport={'width':1440,'height':1080},device_scale_factor=1)
                page.on('pageerror',lambda error: errors.append(str(error)))
                page.goto(f'http://127.0.0.1:{port}',wait_until='networkidle')
                page.get_by_role('heading',name='Обзор исследования').wait_for()
                page.get_by_test_id('stSidebar').get_by_text('Демо · искусственные данные',exact=True).click()
                page.get_by_role('button',name='Загрузить данные',exact=True).click()
                page.locator('[data-testid="stMetricValue"]').first.wait_for()
                page.locator('[data-testid="stPlotlyChart"] .main-svg').first.wait_for()
                page.screenshot(path=str(evidence/'overview.png'))
                page.get_by_test_id('stSidebar').get_by_text('Market Explorer',exact=True).click()
                page.locator('[data-testid="stDataFrame"]').first.wait_for()
                page.get_by_test_id('stSidebar').get_by_text('Time Machine',exact=True).click()
                page.get_by_role('button',name='Рассчитать сценарии',exact=True).click()
                page.get_by_text('Цель первой · доля сценариев',exact=True).wait_for(timeout=30000)
                page.get_by_text('Цель первой · доля сценариев',exact=True).scroll_into_view_if_needed()
                page.screenshot(path=str(evidence/'time-machine.png'))
                page.locator('[data-testid="stPlotlyChart"] .main-svg').first.wait_for()
                page.locator('[data-testid="stPlotlyChart"]').first.scroll_into_view_if_needed()
                page.screenshot(path=str(evidence/'time-machine-chart.png'))
                assert page.locator('[data-testid="stException"]').count()==0
                page.get_by_test_id('stSidebar').get_by_text('Strategy Lab',exact=True).click()
                page.get_by_role('button',name='Проверить стратегию',exact=True).click()
                page.locator('[data-testid="stDataFrame"]').first.wait_for(timeout=30000)
                page.locator('[data-testid="stDataFrame"]').first.scroll_into_view_if_needed()
                page.locator('[data-testid="stPlotlyChart"] .main-svg').first.wait_for()
                page.screenshot(path=str(evidence/'strategy-lab.png'))
                page.get_by_test_id('stSidebar').get_by_text('AI Research',exact=True).click()
                page.get_by_role('button',name='Сформировать отчёт по данным',exact=True).click()
                page.get_by_role('heading',name='Исследование DEMO').wait_for()
                page.get_by_test_id('stSidebar').get_by_text('Portfolio',exact=True).click()
                page.get_by_role('button',name='Сохранить запись',exact=True).click()
                page.get_by_text('Запись сохранена.',exact=True).wait_for()
                page.locator('[data-testid="stMetricValue"]').first.wait_for()
                assert page.locator('[data-testid="stException"]').count()==0
                assert not errors,errors
                browser.close()
            (evidence/'verification.json').write_text(json.dumps({'checked_at_utc':datetime.now(timezone.utc).isoformat(),
                'browser':'Chromium headless via Playwright 1.51.0','pages':6,'simulation_paths':10000,
                'actions':['demo history','candles','simulation','backtest','research report','portfolio deposit'],
                'page_errors':errors,'health':'ok'},ensure_ascii=False,indent=2))
            print('PASS Chromium: six pages, 10000 paths, backtest, report and persisted deposit; screenshots saved')
        finally:
            proc.terminate()
            try:proc.wait(timeout=5)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()


if __name__=='__main__':main()
