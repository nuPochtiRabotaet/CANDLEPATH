import os
from typing import Any
from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings
from mcp.types import ToolAnnotations
from starlette.responses import JSONResponse
from moex import ISS, metrics

hosts = ['127.0.0.1:*', 'localhost:*', '[::1]:*']
public_host = os.getenv('PUBLIC_HOST', '').strip()
if public_host:
    if '/' in public_host or ':' in public_host:
        raise ValueError('PUBLIC_HOST must be hostname only, without https://, path or port')
    hosts.append(public_host)
mcp = FastMCP('MOEX Reader', host=os.getenv('HOST', '127.0.0.1'), port=int(os.getenv('PORT', '8000')),
    stateless_http=True, json_response=True,
    transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=True, allowed_hosts=hosts, allowed_origins=['http://localhost:*','http://127.0.0.1:*'] + ([f'https://{public_host}'] if public_host else [])),
    instructions='Read-only public MOEX data, usually delayed. Always state data timestamps, board and currency. Never treat retrieval time as trade time or historical indicators as certain forecasts. Missing prices remain missing. For decisions separate facts, assumptions, scenarios and invalidation conditions. No brokerage access or trade execution.')
client = ISS()
ann = ToolAnnotations(readOnlyHint=True, destructiveHint=False, idempotentHint=True, openWorldHint=True)

@mcp.tool(annotations=ann)
async def search_security(query: str, limit: int = 10) -> dict[str, Any]:
    """Search MOEX instruments by name/ticker; inspect primary_boardid and asset type before quoting."""
    return await client.search(query, limit)

@mcp.tool(annotations=ann)
async def get_quote(ticker: str, board: str = 'TQBR') -> dict[str, Any]:
    """Get stock/ETF quote and original timestamp/status fields. Default board TQBR. Not bonds. LAST may be null."""
    return await client.quote(ticker, board)

@mcp.tool(annotations=ann)
async def get_daily_history(ticker: str, start: str, end: str, board: str = 'TQBR') -> dict[str, Any]:
    """Get paginated daily stock/ETF history, ISO YYYY-MM-DD dates, maximum 3660 days. Unadjusted prices."""
    return await client.history(ticker, start, end, board)

@mcp.tool(annotations=ann)
async def analyze_history(ticker: str, start: str, end: str, board: str = 'TQBR') -> dict[str, Any]:
    """Compute historical price return, volatility, drawdown, SMA20/50. Not a forecast or total return."""
    history = await client.history(ticker, start, end, board)
    return {k: history[k] for k in ('source','retrieved_at_utc','notice','ticker','board')} | {'metrics': metrics(history)}

@mcp.tool(annotations=ann)
async def get_market_snapshot(tickers: list[str], board: str = 'TQBR') -> dict[str, Any]:
    """Compare 1–10 user-selected stocks/ETFs, keeping partial failures explicit. Not a whole-market index."""
    return await client.snapshot(tickers, board)

@mcp.custom_route('/health', methods=['GET'])
async def health(request):
    return JSONResponse({'status': 'ok', 'service': 'moex-reader', 'version': '0.1.0', 'upstream_checked': False})

if __name__ == '__main__':
    mcp.run(transport='streamable-http')
