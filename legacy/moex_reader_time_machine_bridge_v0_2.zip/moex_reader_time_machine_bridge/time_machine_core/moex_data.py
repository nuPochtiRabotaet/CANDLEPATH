"""Historical daily candles from MOEX ISS, without broker credentials.

The endpoint's historical rows are not guaranteed to be dividend/split adjusted.
"""
from __future__ import annotations
from datetime import date
from urllib.parse import quote
import pandas as pd
import requests

BASE = 'https://iss.moex.com/iss'
TIMEOUT = 18


def _get_json(session: requests.Session, path: str, params: dict) -> dict:
    response = session.get(BASE + path, params=params, timeout=TIMEOUT,
                           headers={'User-Agent': 'MOEX-Time-Machine/0.1 (research, personal use)'})
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict):
        raise RuntimeError('Некорректный ответ ISS.')
    return payload


def detect_market_board(session: requests.Session, symbol: str) -> tuple[str, str, str]:
    # The 'boards' data block reports where the instrument is traded.
    payload = _get_json(session, f'/securities/{quote(symbol)}.json', {'iss.meta': 'off'})
    meta = payload.get('securities', {})
    meta_rows = [dict(zip(meta['columns'], row)) for row in meta.get('data', [])]
    if not meta_rows:
        raise ValueError(f'Тикер {symbol} не найден в ISS Московской биржи.')
    name = str(meta_rows[0].get('SHORTNAME') or symbol)
    boards = payload.get('boards', {})
    records = [dict(zip(boards['columns'], row)) for row in boards.get('data', [])]
    candidates = [r for r in records
                  if str(r.get('engine', r.get('ENGINE', ''))).lower() == 'stock'
                  and str(r.get('market', r.get('MARKET', ''))).lower() == 'shares']
    if not candidates:
        raise ValueError('Пока поддерживаются только акции и фонды из рынка shares.')
    preference = {'TQBR': 0, 'TQTF': 1, 'TQTD': 2, 'TQIF': 3}
    def key(row):
        board = str(row.get('boardid', row.get('BOARDID', '')))
        primary = row.get('is_primary', row.get('IS_PRIMARY', 0))
        return (0 if str(primary) == '1' else 1, preference.get(board, 99))
    board = str(sorted(candidates, key=key)[0].get('boardid', sorted(candidates, key=key)[0].get('BOARDID', '')))
    if not board:
        raise RuntimeError('Не удалось определить режим торгов инструмента.')
    return 'shares', board, name


def load_moex_daily(symbol: str, start_date: date, end_date: date) -> tuple[pd.DataFrame, dict]:
    symbol = symbol.strip().upper()
    if not symbol.isascii() or not symbol.replace('-', '').replace('_', '').isalnum() or len(symbol) > 30:
        raise ValueError('Введите корректный тикер, например SBER или SBMX.')
    if start_date >= end_date:
        raise ValueError('Дата начала должна быть раньше даты конца.')
    with requests.Session() as session:
        market, board, name = detect_market_board(session, symbol)
        path = (f'/history/engines/stock/markets/{market}/boards/{quote(board)}/'
                f'securities/{quote(symbol)}.json')
        all_rows = []
        start = 0
        for _ in range(100):
            data = _get_json(session, path, {
                'from': start_date.isoformat(), 'till': end_date.isoformat(),
                'start': start, 'iss.meta': 'off', 'history.columns': 'TRADEDATE,OPEN,HIGH,LOW,CLOSE,VOLUME',
            })
            history = data.get('history', {})
            columns = history.get('columns', [])
            batch = history.get('data', [])
            if not batch:
                break
            all_rows.extend(dict(zip(columns, row)) for row in batch)
            # Without a next page, a short page also terminates naturally via an empty next fetch.
            start += len(batch)
        if not all_rows:
            raise ValueError('ISS не вернул котировки за этот период. Попробуйте другой тикер.')
    df = pd.DataFrame(all_rows)
    if 'TRADEDATE' not in df or 'CLOSE' not in df:
        raise RuntimeError('Нет нужных колонок в ответе ISS.')
    df['TRADEDATE'] = pd.to_datetime(df['TRADEDATE'], errors='coerce')
    for c in ('OPEN', 'HIGH', 'LOW', 'CLOSE', 'VOLUME'):
        if c in df:
            df[c] = pd.to_numeric(df[c], errors='coerce')
    df = df.dropna(subset=['TRADEDATE', 'CLOSE'])
    df = df[df['CLOSE'] > 0]
    df = df.drop_duplicates(subset=['TRADEDATE'], keep='last').sort_values('TRADEDATE')
    df = df.set_index('TRADEDATE')
    return df, {'symbol': symbol, 'name': name, 'board': board, 'source': 'MOEX ISS'}


def demo_daily(days: int = 420, seed: int = 1007) -> tuple[pd.DataFrame, dict]:
    """Synthetic series used only as an offline demo. Not real prices."""
    import numpy as np
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=days)
    log_ret = rng.normal(0.00025, .014, size=days)
    values = 280 * np.exp(np.cumsum(log_ret))
    df = pd.DataFrame({'CLOSE': values}, index=dates)
    return df, {'symbol': 'DEMO', 'name': 'Искусственные данные (НЕ котировки)',
                'board': 'нет', 'source': 'Сгенерированный пример'}
