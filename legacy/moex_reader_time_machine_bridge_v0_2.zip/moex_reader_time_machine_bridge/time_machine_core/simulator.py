"""Reproducible, close-to-close block-bootstrap scenario simulator.

This does NOT predict future returns or model intraday execution.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd


@dataclass
class SimulationResult:
    paths: np.ndarray
    exits: np.ndarray
    net_returns: np.ndarray
    hit_target: np.ndarray
    hit_stop: np.ndarray
    still_open: np.ndarray
    exit_steps: np.ndarray
    stats: dict


def simulate(
    prices: pd.Series,
    horizon: int = 20,
    runs: int = 10_000,
    target_pct: float = 8.0,
    stop_pct: float = 5.0,
    commission_pct: float = 0.05,
    slippage_pct: float = 0.05,
    block: int = 5,
    seed: int = 42,
) -> SimulationResult:
    """Draw contiguous blocks of historical log returns, then classify first close crossing.

    target_pct, stop_pct, commission_pct, slippage_pct are percentage points.
    Both target/stop hits are determined by simulated *daily closing prices* only.
    Exits occur at the closing price on the first crossing, not at stop/target level.
    """
    series = pd.to_numeric(prices, errors='coerce').replace([np.inf, -np.inf], np.nan).dropna()
    series = series[series > 0]
    if len(series) < 65:
        raise ValueError('Для моделирования нужно как минимум 65 корректных цен закрытия.')
    if not (1 <= horizon <= 252 and 100 <= runs <= 100_000):
        raise ValueError('Некорректный горизонт или количество симуляций.')
    if not (0 < stop_pct < 100 and target_pct > 0 and 0 <= commission_pct < 10 and 0 <= slippage_pct < 10):
        raise ValueError('Некорректные значения цели, стопа или издержек.')
    if not (1 <= block <= 20):
        raise ValueError('Длина блока должна быть от 1 до 20.')

    log_returns = np.diff(np.log(series.to_numpy(dtype=float)))
    block = min(block, len(log_returns), horizon)
    n_blocks = int(np.ceil(horizon / block))
    rng = np.random.default_rng(seed)
    # Each batch preserves short runs of returns (not an IID shuffle of single days).
    choices = rng.integers(0, len(log_returns) - block + 1, size=(runs, n_blocks))
    idx = choices[:, :, None] + np.arange(block)[None, None, :]
    sampled = log_returns[idx].reshape(runs, -1)[:, :horizon]
    initial = float(series.iloc[-1])
    future = initial * np.exp(np.cumsum(sampled, axis=1))
    paths = np.column_stack([np.full(runs, initial), future])

    crossed_stop = future <= initial * (1 - stop_pct / 100)
    crossed_target = future >= initial * (1 + target_pct / 100)
    touched = crossed_stop | crossed_target
    any_touched = np.any(touched, axis=1)
    first = np.argmax(touched, axis=1)
    rows = np.arange(runs)
    hit_stop = any_touched & crossed_stop[rows, first]
    hit_target = any_touched & crossed_target[rows, first]
    still_open = ~any_touched
    exit_steps = np.where(any_touched, first + 1, horizon)
    exits = future[rows, exit_steps - 1]

    one_way = (commission_pct + slippage_pct) / 100
    net_returns = (exits * (1 - one_way)) / (initial * (1 + one_way)) - 1
    n_5 = max(1, int(runs * 0.05))
    worst = np.partition(net_returns, n_5 - 1)[:n_5]
    stats = {
        'start_price': initial,
        'history_points': len(series),
        'p_target': float(hit_target.mean()),
        'p_stop': float(hit_stop.mean()),
        'p_open': float(still_open.mean()),
        'p_loss': float((net_returns < 0).mean()),
        'mean_return': float(net_returns.mean()),
        'median_return': float(np.median(net_returns)),
        'p05_return': float(np.quantile(net_returns, .05)),
        'p95_return': float(np.quantile(net_returns, .95)),
        'cvar05_return': float(worst.mean()),
        'target_price': initial * (1 + target_pct / 100),
        'stop_price': initial * (1 - stop_pct / 100),
        'fee_per_side_pct': commission_pct + slippage_pct,
    }
    return SimulationResult(paths, exits, net_returns, hit_target, hit_stop, still_open, exit_steps, stats)
