"""MOEX Time Machine / educational Monte Carlo dashboard. No orders or accounts."""
from datetime import date, timedelta
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from time_machine_core.moex_data import load_moex_daily, demo_daily
from time_machine_core.simulator import simulate

st.set_page_config(page_title='MOEX Time Machine', page_icon='📈', layout='wide')
st.markdown('''
<style>
.block-container {max-width: 1240px; padding-top: 2.0rem; padding-bottom: 4rem;}
section[data-testid="stSidebar"] {background: #101827;}
[data-testid="stMetric"] {background: #172338; padding: 15px 18px; border-radius: 13px;}
h1,h2,h3 {letter-spacing: -0.025em;}
</style>''', unsafe_allow_html=True)

st.title('MOEX Time Machine')
st.caption('10 000 сценариев для российских акций и фондов · образовательный симулятор · сделки не совершает')
st.info('Результаты — сценарии на основе прошлых дневных доходностей, **не прогноз вероятности заработка**. Стоп и цель проверяются только по закрытиям дней.')

@st.cache_data(ttl=3600, show_spinner=False)
def get_history(symbol, days):
    return load_moex_daily(symbol, date.today() - timedelta(days=days), date.today())

with st.sidebar:
    st.header('Параметры исследования')
    data_mode = st.radio('Источник данных', ('Московская биржа (ISS)', 'Демо — искусственные данные'))
    symbol = st.text_input('Тикер', value='SBER', disabled=data_mode.startswith('Демо')).strip().upper()
    lookback = st.select_slider('Период истории', options=[365, 540, 730, 1095], value=730,
                                format_func=lambda x: {365:'1 год',540:'1,5 года',730:'2 года',1095:'3 года'}[x])
    horizon = st.slider('Горизонт, торговых дней', min_value=5, max_value=120, value=20, step=5)
    runs = st.selectbox('Сценариев', [1000, 5000, 10_000, 20_000], index=2)
    st.divider()
    target_pct = st.number_input('Цель по цене, %', min_value=0.5, max_value=100.0, value=8.0, step=0.5)
    stop_pct = st.number_input('Стоп по цене, %', min_value=0.5, max_value=90.0, value=5.0, step=0.5)
    commission = st.number_input('Комиссия брокера за одну сторону, %', min_value=0.0, max_value=3.0, value=0.05, step=0.01)
    slippage = st.number_input('Условное проскальзывание за одну сторону, %', min_value=0.0, max_value=3.0, value=0.05, step=0.01)
    capital = st.number_input('Размер условной позиции, ₽', min_value=100.0, max_value=1e9, value=5000.0, step=500.0)
    block = st.slider('Размер блока исторических изменений, дней', 1, 10, 5)
    seed = st.number_input('Seed для повторяемости', 0, 1_000_000, 42)
    run = st.button('Рассчитать сценарии', type='primary', use_container_width=True)

if not run:
    st.write('Выбери параметры слева и нажми **«Рассчитать сценарии»**. Для проверки без интернета есть демо-режим на искусственных данных.')
    st.stop()

try:
    if data_mode.startswith('Демо'):
        df, meta = demo_daily()
    else:
        with st.spinner('Получаю исторические цены Московской биржи…'):
            df, meta = get_history(symbol, lookback)
    with st.spinner('Запускаю моделирование…'):
        result = simulate(df['CLOSE'], horizon=horizon, runs=runs, target_pct=target_pct,
                          stop_pct=stop_pct, commission_pct=commission, slippage_pct=slippage,
                          block=block, seed=seed)
except Exception as exc:
    st.error('Не удалось выполнить расчёт: ' + str(exc))
    st.caption('Проверьте соединение с iss.moex.com и тикер. Можно переключиться на демо-режим.')
    st.stop()

s = result.stats
st.subheader(f"{meta['symbol']} · {meta['name']}")
st.caption(f"Источник: {meta['source']} · режим {meta['board']} · последняя дата: {df.index[-1].date()} · дней истории: {s['history_points']:,}".replace(',', ' '))

m = st.columns(5)
m[0].metric('Цель первой', f"{s['p_target']:.1%}")
m[1].metric('Стоп первым', f"{s['p_stop']:.1%}")
m[2].metric('Без достижения', f"{s['p_open']:.1%}")
m[3].metric('Средний результат', f"{s['mean_return']:+.2%}")
m[4].metric('Убыточный итог', f"{s['p_loss']:.1%}")

left, right = st.columns([1.65, 1])
with left:
    st.markdown('#### Веер сценариев')
    xs = np.arange(horizon + 1)
    qs = np.quantile(result.paths, [0.05, 0.25, 0.5, 0.75, 0.95], axis=0)
    fig = go.Figure()
    for qlo, qhi, fillcolor, label in [(0,4,'rgba(46, 163, 218, .14)','5–95%'),(1,3,'rgba(46, 163, 218, .25)','25–75%')]:
        fig.add_trace(go.Scatter(x=xs, y=qs[qlo], mode='lines', line=dict(width=0), showlegend=False, hoverinfo='skip'))
        fig.add_trace(go.Scatter(x=xs, y=qs[qhi], mode='lines', line=dict(width=0), fill='tonexty', fillcolor=fillcolor, name=label))
    fig.add_trace(go.Scatter(x=xs, y=qs[2], mode='lines', line=dict(color='#70d8fb', width=3), name='Медиана'))
    fig.add_hline(y=s['target_price'], line_dash='dash', line_color='#20bc93', annotation_text='Цель')
    fig.add_hline(y=s['stop_price'], line_dash='dash', line_color='#fb7781', annotation_text='Стоп')
    fig.update_layout(height=420, margin=dict(l=0,r=0,t=25,b=15), template='plotly_dark',
                      xaxis_title='Торговых дней от сегодня', yaxis_title='Условная цена, ₽', legend_orientation='h')
    st.plotly_chart(fig, use_container_width=True)
with right:
    st.markdown('#### Первое событие')
    categories = ['Цель', 'Стоп', 'Нет касания']
    values = [s['p_target']*100, s['p_stop']*100, s['p_open']*100]
    fig2 = go.Figure(go.Bar(x=values, y=categories, orientation='h',
                            marker_color=['#20bc93','#fb7781','#7e90ab'],
                            text=[f'{v:.1f}%' for v in values], textposition='inside'))
    fig2.update_layout(height=420, margin=dict(l=8,r=8,t=25,b=15), template='plotly_dark',
                       xaxis=dict(title='Доля симуляций, %', range=[0,100]), yaxis=dict(autorange='reversed'))
    st.plotly_chart(fig2, use_container_width=True)

left, right = st.columns([1.65, 1])
with left:
    st.markdown('#### Распределение итоговой доходности после условных издержек')
    fig3 = go.Figure(go.Histogram(x=result.net_returns*100, nbinsx=60, marker_color='#57b2d9', opacity=.85))
    fig3.add_vline(x=0, line_dash='dash', line_color='#ff8c7b')
    fig3.update_layout(height=320, margin=dict(l=0,r=0,t=15,b=15), template='plotly_dark',
                       xaxis_title='Доходность позиции, %', yaxis_title='Количество сценариев')
    st.plotly_chart(fig3, use_container_width=True)
with right:
    st.markdown('#### Оценка рисков')
    st.metric('5-й процентиль доходности', f"{s['p05_return']:+.2%}")
    st.metric('Среднее худших 5% исходов', f"{s['cvar05_return']:+.2%}")
    st.metric('Ожидаемое изменение условной позиции', f"{capital*s['mean_return']:+,.0f} ₽".replace(',', ' '))
    st.caption('«Ожидаемое» здесь означает среднее по смоделированным исходам, а не прогноз прибыли.')

with st.expander('Исторический график и выгрузка'):
    st.line_chart(df['CLOSE'])
    table = pd.DataFrame({'Сценарий': np.arange(1,runs+1),
                          'Итоговая доходность, %': (result.net_returns*100).round(4),
                          'Итог позиции, ₽': (capital*(1+result.net_returns)).round(2),
                          'День выхода': result.exit_steps,
                          'Исход': np.where(result.hit_stop,'Стоп',np.where(result.hit_target,'Цель','Не достигнуты'))})
    st.download_button('Скачать результаты CSV', table.to_csv(index=False).encode('utf-8-sig'),
                       file_name=f'{meta["symbol"]}_simulation.csv', mime='text/csv')

st.warning('Ограничения: **дневные закрытия**, а не внутридневные свечи; изменение цен в прошлом не гарантирует будущее; возможны корпоративные действия и дивидендные гэпы; нет моделирования ликвидности, налогов и реального исполнения стопов. Комиссия и проскальзывание заданы приближённо. Это не торговый сигнал.')
st.caption('Алгоритм: блочный bootstrap логарифмических изменений за историю; фиксированный seed; первый выход за границы цели/стопа по цене закрытия; если границы не достигнуты — закрытие в последний день горизонта.')
