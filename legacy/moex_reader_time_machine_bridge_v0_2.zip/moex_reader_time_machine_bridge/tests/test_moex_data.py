import unittest
from unittest.mock import patch
import pandas as pd
from time_machine_core.moex_data import detect_market_board, load_moex_daily
from datetime import date

class TestMoexData(unittest.TestCase):
    def test_primary_board_detection(self):
        data = {
            'securities': {'columns':['SECID', 'SHORTNAME'], 'data':[['SBER','Сбербанк']]},
            'boards': {
                'columns': ['boardid', 'engine', 'market', 'is_primary'],
                'data': [['TQOD','stock','shares',0], ['TQBR','stock','shares',1], ['FOOB','stock','bonds',1]]}
        }
        with patch('time_machine_core.moex_data._get_json', return_value=data):
            market, board, name = detect_market_board(None, 'SBER')
        self.assertEqual((market, board, name), ('shares', 'TQBR', 'Сбербанк'))

    def test_pagination_and_nulls(self):
        meta = {'securities': {'columns':['SECID','SHORTNAME'],'data':[['SBER','Сбербанк']]},
                'boards': {'columns':['boardid','engine','market','is_primary'], 'data':[['TQBR','stock','shares',1]]}}
        history = {'history': {'columns': ['TRADEDATE','OPEN','HIGH','LOW','CLOSE','VOLUME'],
                               'data': [['2026-10-20',100,101,99,100.5,300],
                                        ['2026-10-21',101,102,98,None,100],
                                        ['2026-10-22',101,103,101,102,200]]}}
        empty = {'history': {'columns': history['history']['columns'], 'data': []}}
        with patch('time_machine_core.moex_data._get_json', side_effect=[meta, history, empty]):
            frame, details = load_moex_daily('SBER', date(2026,10,1), date(2026,10,24))
        self.assertEqual(len(frame), 2)
        self.assertEqual(details['board'], 'TQBR')
        self.assertAlmostEqual(frame.iloc[-1]['CLOSE'], 102)

if __name__ == '__main__':
    unittest.main()
